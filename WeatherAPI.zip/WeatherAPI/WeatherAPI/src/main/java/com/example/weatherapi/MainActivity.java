package com.example.weatherapi;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    Button button;

    TextView textdayo;
    TextView tempthree;
    EditText edit;
    TextView weatherthree;
    TextView datetime;
    TextView weatherReports1;
    TextView datetimetwo;
    TextView thedate;
    TextView weatherReport2;
    TextView daythree;
    TextView city;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        button =(Button)findViewById(R.id.id_button);
        edit =(EditText) findViewById(R.id.inputCity);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new BackgroundTask().execute();


            }
        });

    }


    public class BackgroundTask extends AsyncTask<String,Void,String>{

    @Override
    protected String doInBackground(String... strings) {
        String apikey= "80e33df41753a2c65eea604316feee1e";
        String county= edit.getText().toString();
        textdayo=findViewById(R.id.id_day);
        tempthree=findViewById(R.id.id_dayth);
        datetime=findViewById(R.id.weatherReport);
        weatherReports1=findViewById(R.id.weatherRe);
        datetimetwo=findViewById(R.id.id_dayt);
        thedate=findViewById(R.id.datetwo);
        weatherReport2=findViewById(R.id.textView2);
        daythree=findViewById(R.id.textView5);
        weatherthree=findViewById(R.id.textView7);
        city=findViewById(R.id.city);
        try {
            URL url = new URL("https://api.openweathermap.org/data/2.5/forecast?q=" + county + "&appid=" + apikey);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setRequestProperty("Content-Type","application/json");
            System.out.println("Get response code: "+ urlConnection.getResponseCode());
            BufferedReader buffer = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

            StringBuilder res = new StringBuilder();
            String input;
            while((input = buffer.readLine())!=null){
                res.append(input);
            }
            buffer.close();
            JSONObject j= new JSONObject(res.toString());
            System.out.println("we " +j.toString());
            Log.d("Tag_1",j.getJSONObject("city").toString());
            Log.d("Tag_2",j.getJSONArray("list").getJSONObject(0).get("weather").toString());
            Log.d("Tag_3",j.getJSONArray("list").getJSONObject(1).getJSONObject("main").get("temp").toString());
            Log.d("Tag_4",j.getJSONArray("list").getJSONObject(1).get("dt_txt").toString());
            Log.d("Tag_5",j.getJSONArray("list").getJSONObject(8).get("dt_txt").toString());
            Log.d("Tag_6",j.getJSONArray("list").getJSONObject(8).get("weather").toString());
            Log.d("Tag_7",j.getJSONArray("list").getJSONObject(9).getJSONObject("main").get("temp").toString());
            Log.d("Tag_8",j.getJSONArray("list").getJSONObject(18).getJSONObject("main").get("temp").toString());
            Log.d("Tag_9",j.getJSONArray("list").getJSONObject(16).get("dt_txt").toString());
            Log.d("Tag_10",j.getJSONArray("list").getJSONObject(16).get("weather").toString());
            city.setText(j.getJSONObject("city").get("name").toString());
            //
            datetime.setText(j.getJSONArray("list").getJSONObject(0).get("dt_txt").toString());
            textdayo.setText(j.getJSONArray("list").getJSONObject(1).getJSONObject("main").get("temp").toString());
            weatherReports1.setText(j.getJSONArray("list").getJSONObject(8).get("weather").toString());
            //
            thedate.setText(j.getJSONArray("list").getJSONObject(8).get("dt_txt").toString());
            datetimetwo.setText(j.getJSONArray("list").getJSONObject(9).getJSONObject("main").get("temp").toString());
            weatherReport2.setText(j.getJSONArray("list").getJSONObject(8).get("weather").toString());
            //
            tempthree.setText(j.getJSONArray("list").getJSONObject(18).getJSONObject("main").get("temp").toString());
            daythree.setText(j.getJSONArray("list").getJSONObject(16).get("dt_txt").toString());
            weatherthree.setText(j.getJSONArray("list").getJSONObject(16).get("weather").toString());
        }catch(Exception e) {

            System.out.println("Hi "+e.getCause());
            e.printStackTrace();
        }
        return null;
    }
}
}